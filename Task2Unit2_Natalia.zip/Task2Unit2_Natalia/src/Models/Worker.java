package Models;

public class Worker {
    private String NIF;
    private String nameEmpleado;
    private String surname;
    private String cargo;

    public Worker(String NIF, String nameEmpleado, String surname, String cargo) {
        this.NIF = NIF;
        this.nameEmpleado = nameEmpleado;
        this.surname = surname;
        this.cargo = cargo;
    }

    public String getNIF() {
        return NIF;
    }

    public void setNIF(String NIF) {
        this.NIF = NIF;
    }

    public String getNameEmpleado() {
        return nameEmpleado;
    }

    public void setNameEmpleado(String nameEmpleado) {
        this.nameEmpleado = nameEmpleado;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    @Override
    public String toString() {
        return super.toString() +
                this.getClass().getName()+"{" +
                "NIF='" + NIF + '\'' +
                ", nameEmpleado='" + nameEmpleado + '\'' +
                ", surname='" + surname + '\'' +
                ", cargo='" + cargo + '\'' +
                '}';
    }


    public int compareTo(Worker w) {
        int r = this.getCargo().compareToIgnoreCase(w.getCargo());
        if (r != 0){
            return r;
        }

        r = this.getSurname().compareToIgnoreCase(w.getSurname());
        if (r != 0){
            return r;
        }

        r = this.getNIF().compareToIgnoreCase(w.getNIF());
        if (r != 0){
            return r;
        }

        return CharSequence.compare(this.NIF, w.NIF);
    }




}
