package Models;

import java.util.Iterator;
import java.util.LinkedList;

public class Departamento {
    private String nameDepartamento;
    private int tamanyo;
    LinkedList<Worker> listaWorkers= new LinkedList<>();

    public Departamento(String nameDepartamento, int tamanyo) {
        this.nameDepartamento = nameDepartamento;
        this.tamanyo = tamanyo;
    }

    public int getTamanyo() {return tamanyo;}

    public void setTamanyo(int tamanyo) {this.tamanyo = tamanyo;}

    public String getNameDepartamento() {return nameDepartamento;}

    public void setNameDepartamento(String nameDepartamento) {this.nameDepartamento = nameDepartamento;}

    public void anyadirWorker(Worker w){
        listaWorkers.add(w);
    }

    public void printWorkers() {
        for (Worker listaWorker : listaWorkers) {
            System.out.println(listaWorker);
        }
    }

    public String printDepartamento() {
        return super.toString() +
                this.getClass().getName()+"{" +
                "nameDepartamento='" + nameDepartamento + '\'' +
                ", tamanyo=" + tamanyo +
                ", listaWorkers=" + listaWorkers +
                '}';
    }


    public String toString() {
        return super.toString() +
                this.getClass().getName()+"{" +
                "nameDepartamento='" + nameDepartamento + '\'' +
                ", tamanyo=" + tamanyo +
                ", listaWorkers=" + listaWorkers +
                '}';
    }


}
