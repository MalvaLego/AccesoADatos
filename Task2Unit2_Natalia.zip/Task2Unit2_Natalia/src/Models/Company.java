package Models;

import Interfaces.ICompany;
import Interfaces.IWorkers;

import java.util.LinkedList;

public class Company implements ICompany, IWorkers {
    private String nameCompany;
    private String CIF;
    LinkedList<Departamento> listaDepartamentos= new LinkedList<>();

    public Company(String nameCompany, String CIF) {
        this.nameCompany = nameCompany;
        this.CIF = CIF;
    }

    public String getNameCompany() {return nameCompany;}

    public void setNameCompany(String nameCompany) {this.nameCompany = nameCompany;}

    public String getCIF() {return CIF;}

    public void setCIF(String CIF) {this.CIF = CIF;}

    public void anyadirDepartamento(Departamento d){
        listaDepartamentos.add(d);
    }

    @Override
    public String toString() {
        return super.toString() +
                this.getClass().getName()+"{" +
                "nameCompany='" + nameCompany + '\'' +
                ", CIF='" + CIF + '\'' +
                ", listaDepartamentos=" + listaDepartamentos +
                '}';
    }

    public Departamento devuelveEmpleados(String name){
        for (Departamento dep: listaDepartamentos){
            if (name.equalsIgnoreCase(dep.getNameDepartamento())){
                return dep;
            }
        }
        return null;
    }

    @Override
    public void devuelveDatosDepartamento(Departamento d){

        d.printWorkers();
    }


    @Override
    public void devuelveDatosEmpleado(String nif) {

    }

    @Override
    public void devuelveListaDepartamentos() {

    }

    @Override
    public void devuelveDepartamentosConMenosEmpleados() {

    }
}
