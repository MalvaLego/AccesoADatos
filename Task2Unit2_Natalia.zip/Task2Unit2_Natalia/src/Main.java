import Models.Company;
import Models.Departamento;
import Models.Worker;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) throws Exception {
        testing();
    }

    private static void testing() throws Exception {
        Company c= new Company("MiCompany","A12345678");

        Departamento d1= new Departamento("depa1",12);
        Departamento d2= new Departamento("depa2",9);
        Departamento d3= new Departamento("depa3",15);

        c.anyadirDepartamento(d1);
        c.anyadirDepartamento(d2);
        c.anyadirDepartamento(d3);

        Worker w1= new Worker("A1234567A","chiara","oliver","carga1");
        Worker w2= new Worker("B1234567B","violeta","hódar","carga2");

        d1.anyadirWorker(w1);
        d1.anyadirWorker(w2);

        Worker w3= new Worker("C1234567C","taylor","swift","carga3");
        Worker w4= new Worker("D1234567D","olivia","rodrigo","carga4");

        d2.anyadirWorker(w3);
        d2.anyadirWorker(w4);

        Worker w5= new Worker("E1234567E","sabrina","carpenter","carga5");
        Worker w6= new Worker("F1234567F","emma","watson","carga6");

        d3.anyadirWorker(w5);
        d3.anyadirWorker(w6);


        findDepartmentEmployees(c,"depa1");
        findDepartmentByName(c,"depa4");
        findEmployeeByNif();
    }

    private static void findDepartmentEmployees(Company c, String name) throws Exception {
        Departamento dep= c.devuelveEmpleados(name);

        if (dep!=null){
            dep.printWorkers();
        }else{
            throw new Exception("no se ha encontrado el departamento");
        }
    }

    private static void findDepartmentByName(Company c, String name) throws Exception {
        Departamento dep= c.devuelveEmpleados(name);

        if (dep!=null){
            dep.printDepartamento();
        }else{
            throw new Exception("no se ha encontrado el departamento");
        }

    }

    private static void findEmployeeByNif(){

    }

}