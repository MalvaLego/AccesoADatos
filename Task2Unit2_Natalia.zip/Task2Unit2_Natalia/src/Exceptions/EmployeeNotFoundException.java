package Exceptions;

public class EmployeeNotFoundException extends RuntimeException {
    private String nifEmployee;

    public EmployeeNotFoundException(String nif) {
    this.nifEmployee=nif;
  }

    public String getNifEmployee(){
      return nifEmployee;
    }

}
