package Exceptions;

public class DepartmentNotFoundException extends Throwable {
    private String depaName;

    public DepartmentNotFoundException(String name) {
    this.depaName=name;
  }

    public String getDepaname(){
      return depaName;
    }


}
