package Interfaces;

import Models.Departamento;

public interface IWorkers {
    public void devuelveDatosEmpleado(String nif);
    public void devuelveListaDepartamentos();
    public void devuelveDepartamentosConMenosEmpleados();


}
