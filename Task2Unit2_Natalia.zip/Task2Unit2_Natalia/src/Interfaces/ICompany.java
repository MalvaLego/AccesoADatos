package Interfaces;

import Models.Departamento;

public interface ICompany {

    public Departamento devuelveEmpleados(String name);
    public void devuelveDatosDepartamento(Departamento d);

}
