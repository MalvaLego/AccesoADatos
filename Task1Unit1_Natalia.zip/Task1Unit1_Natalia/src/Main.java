import Models.Entrenador;
import Models.Futbolistas;
import Models.Masajista;
import Models.SeleccionFutbol;

import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;

public class Main {
    public static void main(String[] args) {
        LinkedList<SeleccionFutbol> lista= new LinkedList<SeleccionFutbol>();
        testing(lista);
    }

    //Create a Main class, containing a linkedList of Selections(Staff), with at
    //least 3 players, 2 coaches and 1 masseuse.
    public static void testing(LinkedList<SeleccionFutbol> lista){
        Futbolistas f1= new Futbolistas(1,"chiara","oliver",20,3,"delantero");
        Futbolistas f2= new Futbolistas(2,"violeta","hódar",23,7,"defensa");
        Futbolistas f3= new Futbolistas(3,"sabrina","carpenter",25,4,"lateral");
        Entrenador e1= new Entrenador(4,"taylor","swift",34,1);
        Entrenador e2= new Entrenador(5,"olivia","rodrigo",21,2);
        Masajista m1= new Masajista(5,"chappel","roan",26,"titulado",5);

        lista.add(f1);
        lista.add(f2);
        lista.add(f3);
        lista.add(e1);
        lista.add(e2);
        lista.add(m1);

        //Iterates through the list using a for loop and displays the “complete” info for each
        //object using a casting.
        print_all(lista);
        System.out.println("----------------------------------------------");

        //Create a method that receives as a parameter an object of the Object class,
        //and prints all the information of the passed object by using casting and instanceof
        print_obj(lista.get(4)); // <-- Esto es un ejemplo
        System.out.println("----------------------------------------------");

        //Displays how many objects of each subclass the LinkedList contains.
        numObjects(lista);
        System.out.println("----------------------------------------------");

        //Displays the list of staff sorted by age,name and ID.
        ordened(lista);
        print_all(lista);
    }

    public static void print_all(LinkedList<SeleccionFutbol> lista){
        for (int i=0;i<lista.size();i++){
            if (lista.get(i) instanceof Futbolistas f){
                System.out.println(f.toString());
            }
            if (lista.get(i) instanceof Entrenador e){
                System.out.println(e.toString());
            }
            if (lista.get(i) instanceof Masajista m){
                System.out.println(m.toString());
            }
        }
    }

    public static void print_obj(Object ob){
        System.out.println(ob.toString());
        if (ob instanceof Futbolistas){
            Futbolistas fb=(Futbolistas)ob;
        } else if (ob instanceof Entrenador){
            Entrenador fb=(Entrenador)ob;
        } else if (ob instanceof Masajista){
            Masajista fb=(Masajista)ob;
        }
    }

    public static void numObjects(LinkedList<SeleccionFutbol> lista){
        int numFut=0;
        int numEn=0;
        int numMas=0;

        for (int i=0;i<lista.size();i++){
            if (lista.get(i) instanceof Futbolistas f){
                numFut++;
            }
            if (lista.get(i) instanceof Entrenador e){
                numEn++;
            }
            if (lista.get(i) instanceof Masajista m){
                numMas++;
            }
        }
        System.out.println("Num de Futbolistas: "+numFut);
        System.out.println("Num de Entrenadores: "+numEn);
        System.out.println("Num de masajistas: "+numMas);
    }

    public static void ordened(LinkedList<SeleccionFutbol> lista){
        Collections.sort(lista );
        //FALTA COMPARAR CON LOS DATOS
    }




}