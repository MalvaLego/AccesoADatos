package Models;

import Interfaces.Interfacee;

public class SeleccionFutbol implements Interfacee, Comparable<SeleccionFutbol> {
    private int id;
    private String nombre;
    private String apellidos;
    private int edad;

    public SeleccionFutbol(int id, String nombre, String apellidos, int edad) {
        this.id = id;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.edad = edad;
    }

    public void setId(int id) {this.id = id;}

    public void setNombre(String nombre) {this.nombre = nombre;}

    public void setApellidos(String apellidos) {this.apellidos = apellidos;}

    public void setEdad(int edad) {this.edad = edad;}

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public int getEdad() {
        return edad;
    }

    @Override
    public String toString() {
        return getClass().getSimpleName()+"SeleccionFutbol{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", apellidos='" + apellidos + '\'' +
                ", edad=" + edad +
                '}';
    }

    @Override
    public void Concentrarse() {
        System.out.println("Concentrando...");
    }

    @Override
    public void Viajar() {
        System.out.println("viajando...");
    }

    @Override
    public int compareTo(SeleccionFutbol o) {
        //FALTA COMPROVAR OTROS EJS
        return 0;
    }
}
