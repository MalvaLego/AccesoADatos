package Models;

import Interfaces.InterEntrena;

public class Entrenador extends SeleccionFutbol implements InterEntrena {
    private int idFederacion;

    public Entrenador(int id, String nombre, String apellidos, int edad, int idFederacion) {
        super(id, nombre, apellidos, edad);
        this.idFederacion = idFederacion;
    }

    @Override
    public String toString() {
        return super.toString()+" "+getClass().getSimpleName()+"{" +
                "idFederacion=" + idFederacion +
                "} " + super.toString();
    }

    @Override
    public void dirigirPartido() {
        System.out.println("dirigiendo partido...");
    }

    public int getIdFederacion() {
        return idFederacion;
    }

    @Override
    public void dirigirEntrenamiento() {
        System.out.println("dirigiendo entre...");
    }
}
