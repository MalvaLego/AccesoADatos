package Interfaces;

public interface InterMasaj {

    public void darMasaje();
}
