package Interfaces;

public interface Interfacee {

    public void Concentrarse();
    public void Viajar();

}
