package Interfaces;

public interface InterEntrena {

    public void dirigirPartido();
    public void dirigirEntrenamiento();

}
