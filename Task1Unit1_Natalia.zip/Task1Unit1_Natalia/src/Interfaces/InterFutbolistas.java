package Interfaces;

public interface InterFutbolistas {

    public void jugarPartido();
    public void entrenar();
}
